typedef enum { false, true } bool; 

typedef unsigned char uchar;      //using uchar as shorthand
uchar pack(uchar cells[8]);
